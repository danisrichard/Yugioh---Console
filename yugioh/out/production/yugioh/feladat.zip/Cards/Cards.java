package Cards;

/**
 * Created by Domician on 2017. 04. 10..
 */
public abstract class Cards {
    protected String cardName;

    public Cards( String cardName) {
        this.cardName = cardName;
    }
}
