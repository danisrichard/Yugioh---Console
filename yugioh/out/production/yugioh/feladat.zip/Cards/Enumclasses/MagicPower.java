package Cards.Enumclasses;

/**
 * Created by Domician on 2017. 04. 11..
 */
/*
    csak megadja mit kellene csinálni majd a kártyának mikor meghivjük
    támadó erőt,védekezését vagy életet növel majd
 */

public enum MagicPower {
    ATTACKUP,DEFFENDUP,HEALTHUP
}
