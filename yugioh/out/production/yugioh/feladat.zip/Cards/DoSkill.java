package Cards;
import Player.Player;

/**
 * Created by Domician on 2017. 04. 11..
 */
public interface DoSkill {
    void doUnique(Player obj);
}
